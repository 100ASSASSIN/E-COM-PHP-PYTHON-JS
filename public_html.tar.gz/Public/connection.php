<?php
$con=mysqli_connect("localhost","u967353045_assassin01","Aus@9047672441","u967353045_root") or die(mysqli_error($con));
//$con=mysqli_connect("localhost","root","","store") or die(mysqli_error($con));
// Create connection
?>