<?php
include "Home.php";
include "nav-bar.php";
include "Footer.php";
?>