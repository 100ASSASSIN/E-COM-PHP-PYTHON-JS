<head>
<link rel="stylesheet" href="Components/navbar/navbar-plugin.css">
<link rel="stylesheet" href="Assets/icons/font-awesome-4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo $_SERVER['DOCUMENT_ROOT'] . 'Components/navbar/navbar-plugin.css'; ?>">
<link rel="stylesheet" href="<?php echo $_SERVER['DOCUMENT_ROOT'] . 'Assets/icons/font-awesome-4.7.0/css/font-awesome.min.css'; ?>">
</head>
    <div id=top-row>
    <ul class="nav-links">
    <li><a href="index.php"><i class="fa fa-rebel" aria-hidden="true"></i> ASSASSIN</a></li>
    <li class="center"><a href="index.php">HOME</a></li>
    <li class="center"><a href="#">PRODUCT</a></li>
    <li class="upward"><a href="#">sign up</a></li>
    <li class="center"><a href="\Root\Public\login.php"><i class="fa fa-user-plus" aria-hidden="true"></i> Log in</a></li>
    <li class="forward"><a href="\Root\public\cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i> CART</a></li>
    </ul>
    </div>
    