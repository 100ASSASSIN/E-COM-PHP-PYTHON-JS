<?php    
session_start();
?>
<meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="apple-touch-icon" sizes="180x180" href="https://cdn.oaistatic.com/_next/static/media/apple-touch-icon.59f2e898.png"/><link rel="icon" type="image/png" sizes="32x32" href="https://cdn.oaistatic.com/_next/static/media/favicon-32x32.be48395e.png"/><link rel="icon" type="image/png" sizes="16x16" href="https://cdn.oaistatic.com/_next/static/media/favicon-16x16.9b8dbb69.png"/>
	<title>ASSASSIN-AUS-01</title>
    <link rel="stylesheet" href="Assets\styles\all-main.css">
    <link rel="stylesheet" href="Components/buttons/B-plugin.css">
    <link rel="stylesheet" href="Assets/fonts/font.ttf">
    <link rel="stylesheet" href="Layouts/top-row.css">
    <link rel="stylesheet" href="Components/Preload/preload.css">
    <link rel="stylesheet" href="Components/navbar/navbar-plugin.css">
    <link rel="stylesheet" href="Components/modal/Product.css">
    <link rel="stylesheet" href="Components/footer/footer-plugin.css">
    <link rel="stylesheet" href="Assets/icons/font-awesome-4.7.0/css/font-awesome.min.css">

   <!--bootstarp-link-->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
   <!--bootstarp-version-4 -->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
   <!--SCRIPT-->
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   <!--icons-->
   <script src="https://kit.fontawesome.com/f538f1ee6e.js" crossorigin="anonymous"></script>
   <script src="https://kit.fontawesome.com/9078fb565f.js" crossorigin="anonymous"></script>
   <script src="Composables\com.js"></script>
   <script src="Features/fu.js"></script>
   <script src="Components/Preload/preload.js"></script>
   <!--OTP-GEN-->
   <script src="Context/otp_gen/OTP.js"></script>
</head>
<div id="preloader"></div>
<div id="DIV1">
    <div class="grid-containe">
  <div class="grid-item">
  <a href="http://google.com">
  <img src="Assets/img/Home-pag/img1.webp" alt="img1"></a></div>
  <div class="grid-item">
  <a href="http://google.com">
  <img src="Assets/img/Home-pag/img2.webp" alt="img2"></a></div>
  <div class="grid-item">
  <a href="http://google.com">
  <img src="Assets/img/Home-pag/img3.webp" alt="img3"></a></div>
  <div class="grid-item">
  <a href="http://google.com">
  <img src="Assets/img/Home-pag/img4.webp" alt="img4"></a></div>
  <div class="grid-item">
  <a href="http://google.com">
  <img src="Assets/img/Home-pag/img5.webp" alt="img5"></a></div>
  <div class="grid-item">
  <a href="http://google.com">
  <img src="Assets/img/Home-pag/img6.webp" alt="img6"></a></div>
  <div class="grid-item">
  <a href="http://google.com">
  <img src="Assets/img/Home-pag/img7.webp" alt="img7"></a></div>
  <div class="grid-item">
  <a href="http://google.com">
  <img src="Assets/img/Home-pag/img8.webp" alt="img8"></a></div>
  </div>
  
<div class="grid-con">
  <div class="grid-i">
  <a href="/Root/public/page1.php">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1">
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)</a>
<center><h4 style="color: red;">Rs. 111,852</h4></center>
</div>
<div class="grid-i">
  <a href="/Root/Public/page2.php">
  <img src="Assets/img/pro-sec/img2.webp" alt="img2">
  MSI 1 - Adobe Premier Pro (I9 13900KF / RTX 4080 / 32GB)</a>
</div>
<div class="grid-i">
  <a href="https://elitehubs.com/collections/prebuilt-gaming-pc/products/msi-2-davinci-i7-13700k-rtx-4080-32gb-ram-1tb-m-2-nvme-gen4-ssd">
  <img src="Assets/img/pro-sec/img3.jpg" alt="img3">
  MSI 2 - Davinci (I7 13700K / RTX 4080 / 32GB RAM / 1TB...</a>
</div>
<div class="grid-i">
  <a href="https://elitehubs.com/collections/prebuilt-gaming-pc/products/msi-3-blender-i9-13900kf-rtx-4080-32gb-ram-1tb-m-2-nvme-gen4-ssd">
  <img src="Assets/img/pro-sec/img4.jpg" alt="img4">
  MSI 3 - Blender (I9 13900KF / RTX 4080 / 32GB RAM / 1TB</a>
</div>
<div class="grid-i">
  <a href="https://elitehubs.com/collections/prebuilt-gaming-pc/products/egw14">
  <img src="Assets/img/pro-sec/img5.webp" alt="img5">
  FPS-Pro White 16 - ESports Gaming PC (Ryzen 7 7700X / RTX 4070 / 32GB RAM /500GBNVMe)</a>
</div>
<div class="grid-i">
  <a href="https://elitehubs.com/products/cg03">
  <img src="Assets/img/pro-sec/img6.webp" alt="img6">
  Leisure-Pro 09 - Casual Gaming PC (Core I5 12400F / RTX 4060 / 16GB RAM / 500GB NVMe SSD)</a>
</div>
<div class="grid-i">
  <a href="https://elitehubs.com/products/cg04">
  <img src="Assets/img/pro-sec/img7.webp" alt="img7"></a>
  Leisure-Pro 11 - Casual Gaming PC (Core I5 13400F / RTX 4060 / 16GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="https://elitehubs.com/products/cgw02">
  <img src="Assets/img/pro-sec/img8.webp" alt="img8"></a>
  Leisure-Pro 03 White - Casual Gaming PC (Core I5 12400F / GTX 1650 / 16GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="https://elitehubs.com/products/streaming-01">
  <img src="Assets/img/pro-sec/img9.webp" alt="img9"></a>
  Streamer-Lite 01 - Streaming PC (Core I5 12400F / RTX 3050 / 16GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="https://elitehubs.com/products/aaa13">
  <img src="Assets/img/pro-sec/img10.webp" alt="img10"></a>
  Quest-Legend 20 - AAA Gaming PC (Ryzen 9 7950X3D / RTX 4090 / 32GB RAM / 1TB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
<div class="grid-i">
  <a href="http://google.com">
  <img src="Assets/img/pro-sec/img1.webp" alt="img1"></a>
  Streamer-Pro 09 - Streaming PC (Core I5 13400F / RTX 4060 Ti / 32GB RAM / 500GB NVMe SSD)
</div>
  </div>
    <!--END-DIV3-->
  </div>
  <!--END-DIV1-->
</div>
</div>
</div>

<!--pre-loader-->
   <!--div loader -->
   
    <!--pre-loader-->
<script>
    var loader = document.getElementById("preloader");
    window.addEventListener("load", function(){
    loader.style.display = "none";
    });
</script>
</body>
</html>
