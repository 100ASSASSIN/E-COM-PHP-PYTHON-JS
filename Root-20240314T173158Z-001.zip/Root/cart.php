<?php 
session_start ();
include "nav-bar.php";
include "project/ASSASSIN/cart.php";
echo "<div class='test'>CART</div>";
?>
<style>
.test{
background-color:WHITE; 
font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
font-size: larger;
font-weight: bolder;
display: flex;
position: absolute;
top: 100px;
left: 40px;
}
</style>

